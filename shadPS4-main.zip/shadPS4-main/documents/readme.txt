shadPS4 - A PS4 emulator
=========================

1. Intro
2. Current status
3. Contributors
4. Greetings

1.Intro
=======
shadPS4 is a Play Station 4 emulator for Windows and Linux. Although atm it can't run a lot of stuff, we are working torwards to make it more compatible.

2.Current status
================
shadPS4 is a HLE emulator. Currently on a small amount of functions is emulated, which is one of the reasons compatibility is low.

3.Contributors
==============
- georgemoralis
- raphaelthegreat
- skmp
- wheremyfoodat

4.Greetings
===========
I would like to thank the following people for helping me so far, with coding or moral support.

- wheremyfoodat - or @rodakinos for believed me
- paris - or OFFTKP for not believing me and that made me a better coder :D
- skmp - or kornilios for being good old friend
- PandaBad - our beloved stalker
- emufan4568 - for advices
- velocity - for talking 1-2 times per year on discord server. We miss you velocity

- probably more, will include in the next readme :D
